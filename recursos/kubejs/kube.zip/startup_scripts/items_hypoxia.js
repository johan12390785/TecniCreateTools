StartupEvents.registry('item', event => {

    // --- 1. MATERIALES ---
    event.create('acero_bunker')
         .displayName('Acero de Bunker')
         .tooltip('§7Aleacion pesada usada para blindaje.')

    event.create('polimero_toxico')
         .displayName('Polimero Endurecido')
         .tooltip('§7Manegar con cuidado.')

    event.create('chatarra')
         .displayName('Basura Metalica')
         .tooltip('§7La chatarra puede llegar a ser oro')

    event.create('filtro_aire')
         .displayName('Filtro de Carbon Activo')
         .maxStackSize(8)
         .tooltip('§7Usalo mientras tienes la mascara puesta para recargarla.')

    // --- 2. HERAMIENTAS ---
    event.create('sable_acero', 'sword')
         .displayName('Sable de Acero Reforzado')
         .unstackable()
         .maxDamage(1561)
         .attackDamageBaseline(4)
         .speedBaseline(-2.4)
         .tooltip('§7Sable posible de cortar hasta madera.')

    event.create('machete_tactico', 'sword')
         .displayName('Machete Tactico')
         .unstackable()
         .maxDamage(2031)
         .fireResistant(true)
         .attackDamageBaseline(6)
         .speedBaseline(-2.4)
         .tooltip('§7Para comida y para matar.')

    event.create('martillo_trabajo', 'pickaxe')
         .displayName('Martillo Forjador')
         .unstackable()
         .maxDamage(250)
         .speedBaseline(-2.0)
         .tooltip('§7Forja casi cualquier metal.')
})
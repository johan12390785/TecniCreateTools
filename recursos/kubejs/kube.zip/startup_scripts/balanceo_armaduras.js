// UBICACIÓN: kubejs/startup_scripts/balanceo_armaduras.js
// ESTADO: SEGURO (Solo números, sin texto)

ItemEvents.modification(event => {

    // --- TIER 1: TORTUGA ---
    event.modify('minecraft:turtle_helmet', item => {
        item.armorProtection = 2      
        item.armorToughness = 0       
        item.armorKnockbackResistance = 0  
    })

    // --- TIER 2: COBRE ---
    event.modify('create:copper_diving_helmet', item => {
        item.armorProtection = 3      
        item.armorToughness = 1       
        item.armorKnockbackResistance = 0 
    })

    event.modify('create:copper_backtank', item => {
        item.armorProtection = 6      
        item.armorToughness = 1
        item.armorKnockbackResistance = 0.1 
    })

    // --- TIER 3: NETHERITE ---
    event.modify('create:netherite_diving_helmet', item => {
        item.armorProtection = 4      
        item.armorToughness = 4       
        item.armorKnockbackResistance = 0.1 
    })

    event.modify('create:netherite_backtank', item => {
        item.armorProtection = 9      
        item.armorToughness = 4
        item.armorKnockbackResistance = 0.2 
    })
})
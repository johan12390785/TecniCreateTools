// UBICACIÓN: kubejs/client_scripts/nombres_items.js
// DESCRIPCIÓN: Renombra los objetos en Español (España, México, Chile, etc.) e Inglés.

const RENOMBRES = {
    // Tier 1
    'item.minecraft.turtle_helmet': 'Mascara Antigas (Tier 1)',
    
    // Tier 2
    'item.create.copper_diving_helmet': 'Visor Militar (Tier 2)',
    'item.create.copper_backtank': 'Tanque de Oxigeno Militar',
    
    // Tier 3
    'item.create.netherite_diving_helmet': 'Casco H.A.Z.M.A.T. (Tier 3)',
    'item.create.netherite_backtank': 'Soporte Vital Blindado',
    
    // Nuestro Filtro
    'item.kubejs.filtro_aire': 'Filtro de Carbon Activo'
}

// Aplicar a Inglés (por si acaso)
ClientEvents.lang('en_us', event => {
    Object.keys(RENOMBRES).forEach(key => {
        event.add(key, RENOMBRES[key])
    })
})

// Aplicar a TODAS las variantes de Español
const IDIOMAS_ESP = ['es_es', 'es_mx', 'es_ar', 'es_cl', 'es_uy', 'es_ve']

IDIOMAS_ESP.forEach(idioma => {
    ClientEvents.lang(idioma, event => {
        Object.keys(RENOMBRES).forEach(key => {
            event.add(key, RENOMBRES[key])
        })
    })
})
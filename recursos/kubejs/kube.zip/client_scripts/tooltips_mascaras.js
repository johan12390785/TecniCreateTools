// UBICACIÓN: kubejs/client_scripts/tooltips_mascaras.js

const TIEMPOS_FILTRO = {
    'minecraft:turtle_helmet': 300,
    'create:copper_diving_helmet': 900,
    'create:netherite_diving_helmet': 1800
}
const MASCARAS = Object.keys(TIEMPOS_FILTRO)

ItemEvents.tooltip(event => {
    // TOOLTIPS DE MÁSCARAS
    event.addAdvanced(MASCARAS, (item, advanced, text) => {
        let maxVida = TIEMPOS_FILTRO[item.id] || 900
        
        // Estado del filtro
        if (item.nbt && item.nbt.contains('FilterLife')) {
            let vida = item.nbt.getInt('FilterLife')
            text.add(1, Text.of(`Filtro: ${vida}/${maxVida}s`).green())
        } else {
            text.add(1, Text.gray(`Capacidad: ${maxVida} seg`))
        }

        // Historia (Lore)
        if (item.id == 'minecraft:turtle_helmet') {
            text.add(2, Text.gray("Un filtro comun y estable."))
            text.add(3, Text.darkRed("Sellado deficiente."))
        }
        if (item.id == 'create:copper_diving_helmet') {
            text.add(2, Text.gray("Equipamiento militar."))
            text.add(3, Text.aqua("Sellado hermetico confiable."))
        }
        if (item.id == 'create:netherite_diving_helmet') {
            text.add(2, Text.of("Proteccion total contra radiacion.").color('#AA00AA'))
        }
    })

    // TOOLTIPS DE TANQUES
    event.add('create:copper_backtank', [
        Text.aqua("Eficiencia: Estandar (30 Min)"),
        Text.red("⚠ PESADO: Solo puedes llevar 1.")
    ])

    event.add('create:netherite_backtank', [
        Text.of("Eficiencia: Alta (1 Hora)").color('#AA00AA'),
        Text.red("MUY PESADO: +50% Resistencia Knockback."),
        Text.red("⚠ Solo puedes llevar 1.")
    ])
})